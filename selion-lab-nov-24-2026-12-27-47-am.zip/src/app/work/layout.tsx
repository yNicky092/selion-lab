import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Silicon Emergence · Selion Lab",
  description:
    "Explore Silicon Emergence (72 levels, 6 chapters, and Infinite Sandbox on Desktop and Android), a 3D VLSI hardware-engineering game built on real silicon physics.",
  alternates: {
    canonical: "/work/",
  },
  openGraph: {
    title: "Silicon Emergence · Selion Lab",
    description:
      "From a single transistor to a working computer, built with real silicon physics.",
    url: "https://selionlab.com/work/",
    images: [
      {
        url: "/images/silicon-emergence-vlsi.jpg",
        width: 1280,
        height: 714,
        alt: "Silicon Emergence 3D FinFET transistors and Glass-Box IC",
      },
    ],
  },
};

export default function WorkLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return children;
}
